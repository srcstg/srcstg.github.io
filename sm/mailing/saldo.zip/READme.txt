 ____   ___  ____  ______   ____  __  ___  __  __ 
/ ___| / _ \|  _ \|  _ \ \ / /  \/  |/ _ \|  \/  |
\___ \| | | | |_) | |_) \ V /| |\/| | | | | |\/| |
 ___) | |_| |  _ <|  _ < | | | |  | | |_| | |  | |
|____/ \___/|_| \_\_| \_\|_| |_|__|_|\___/|_|  |_|
|  _ \| ____\ \   / / |_   _| ____|  / \  |  \/  |
| | | |  _|  \ \ / /    | | |  _|   / _ \ | |\/| |
| |_| | |___  \ V /     | | | |___ / ___ \| |  | |
|____/|_____|  \_/      |_| |_____/_/   \_\_|  |_|

Hola!
este readme tiene el objetivo de informar sobre la ubicación de los textos dinámicos dentro del HTML.

La advertencia está en:

<!-- Texto principal -->

<p>Hola <strong>XXXX</strong>,</p>

<p>¡Te recordamos que tu saldo de <strong>XXXX</strong> ya está disponible!</p>

<p><strong>Tu saldo es de:</strong> XXXX</p>

<p><em>*Recuerda que tu saldo vence el XX/XX/XXXX</em></p></div>

